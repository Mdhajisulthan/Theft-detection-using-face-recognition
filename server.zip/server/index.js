const express = require('express')
const bodyParser = require('body-parser');
const http = require('http')
const path = require('path')
var fs = require('fs')
const mongoose = require('mongoose')

const app = express()

const PORT = process.env.PORT || 8080

const atmRoute = require('./routes/atm');
const allocRoute = require('./routes/alloc');

app.use(bodyParser.json({limit : '50mb'}));
app.use(bodyParser.urlencoded({limit : '50mb',extended: false}));
app.use('/atm/users', atmRoute)
app.use('/atm/alloc', allocRoute)

const url = 'mongodb://127.0.0.1:27017/'

const dbName = 'atm'

mongoose.set('strictQuery', false)

mongoose.connect(url+dbName).then(
    console.log("db connected")
).catch(
    console.error
)

app.listen(PORT, () => {
    console.log("Listening to port %d",PORT)
})
