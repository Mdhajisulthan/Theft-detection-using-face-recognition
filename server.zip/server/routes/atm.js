var router = require('express').Router()
var user = require('../models/userModel')

router.get('/all', async (req, res) => {
    var users = await user.find().exec((err, resp) => {
        if(err) console.error
        else {
            console.log(resp)
            res.send(resp)

        }
    })
})

router.post('/register',async (req,res) => {
    const setUser = new user({
        'id': req.body['id'],
        'username': req.body['username'],
        'accessFrom': req.body['from'],
        'accessTo': req.body['to']
    })
    await setUser.save((err,resp) => {
        if(err) console.error
        else {
            console.log(resp)
            res.send(resp)
        }
    })    
})

router.post('/getUser', async (req, res) => {
    user.findOne({'id': req.body['id']}).exec((err, resp) => {
        if(err) console.error
        else {
            if(resp === null) {                
                res.send('none')
            } else {
                res.send(resp)
            }
        }
    })
})

module.exports = router