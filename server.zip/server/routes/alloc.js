var router = require('express').Router()
var alloc = require('../models/allocModel')

router.post('/amount', async (req, res) => {
    alloc.findOne({'atmId': req.body['id']}).exec((err, resp) => {
        if(err) console.error
        else {
            if(resp === null) {                
                res.send('none')
            } else {
                res.send(resp)
            }
        }
    })
})

router.post('/register',async (req,res) => {
    const setUser = new alloc({
        'atmId': req.body['id'],
        'amount': req.body['amount']
    })
    await setUser.save((err,resp) => {
        if(err) console.error
        else {
            console.log(resp)
            res.send(resp)
        }
    })    
})

module.exports = router