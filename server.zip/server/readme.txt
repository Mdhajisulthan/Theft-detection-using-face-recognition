#For running process use the code in terminal
cd front
python home.py
cd server 
npm run dev

#pre-process database

before that connect with the db(mongodbcompass)
for insert the data use - postman 

#step-1 face recongination

use the classifier called(haar cascade)
to extract the feature of face

#step-2 otp verification
 
For the OTP using the "twilio" server 
To provide the alert msg to the respective bank

#Time range
 
we have the time range for the id to access the ATM

#Final step

balance checker
weather the deposite amount is correct or not 

#End of the project