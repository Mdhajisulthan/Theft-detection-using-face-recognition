var mongoose = require('mongoose')
var schema = mongoose.Schema;

var allocSchema = new schema({
    "atmId": String,
    "amount": String,
})

module.exports = mongoose.model('allocation', allocSchema)