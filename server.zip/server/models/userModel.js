var mongoose = require('mongoose')
var schema = mongoose.Schema;

var userSchema = new schema({
    "id": String,
    "username": String,
    "accessFrom": String,
    "accessTo": String
})

module.exports = mongoose.model('user', userSchema)