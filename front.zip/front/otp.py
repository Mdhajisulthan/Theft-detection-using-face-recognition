import random

class OPTGenerator:
    def __init__(self):
        pass

    def generate(self):
        otp = random.randint(1000,9999)
        return otp