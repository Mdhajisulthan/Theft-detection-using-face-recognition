import flet as ft
import base64
import cv2
import time
import threading
from faceencoding import FaceEncoding
import face_recognition
import numpy as np
import requests
import datetime
from otp import OPTGenerator
from twilio.rest import Client

atmID = "101"
bank_num = "+919042007226"

face_names = ''
streaming = True

currentBalance = 50000
approvedDeposit = 0
installedAmount = 0

acc_sid = 'ACe2784bc38d3e98e4cdbb229bae508374' #account sid from twilio

auth_token = 'd74d3947655e477eba3025127c96e1d0' #auth token from twilio

client = Client(acc_sid, auth_token)

def main(page: ft.Page):

    def fifthPage(e):

        def windowClose(e):
            page.window_close()

        page.clean()
        page.add(
            ft.Container(
                content=ft.Column(            
                    [
                        ft.Container(
                            padding=ft.padding.only(bottom=25),
                            content=ft.Text('Complete',size=50),
                        ),
                        ft.Container(
                            padding=ft.padding.only(bottom=0),
                            content=ft.Text('Installation of money has been successfully processed. Please exit.'),
                        ),
                        ft.Container(
                            padding=ft.padding.only(top=25),
                            content=ft.ElevatedButton(
                                bgcolor=ft.colors.RED_700,
                                text="Exit",
                                color=ft.colors.WHITE,
                                on_click=windowClose,                            
                            )

                        ),                        
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                ),
                width=800,
                expand=True,
            )
        )

    def fourthPage(e):
        page.clean()
        global approvedDeposit

        req = requests.post("http://192.168.19.224:8080/atm/alloc/amount",json={"id": atmID})

        approvedDeposit = int(req.json()['amount'])

        c = ft.Text(f'Current Balance: Rs.{currentBalance}')
        d = ft.Text(f'Approved Deposit: Rs.{approvedDeposit}')
        i = ft.Text(f'Installed Amount: Rs.{installedAmount}')

        m = ft.Text('',color=ft.colors.AMBER)

        def counter(e):

            b.disabled=True
            b.update()

            dummyAmount = 5000


            global approvedDeposit
            global installedAmount
            global currentBalance
            while installedAmount < dummyAmount:
                installedAmount += 1
                currentBalance += 1
                i.value = f'Installed Amount: Rs.{installedAmount}'
                c.value = f'Current Balance: Rs.{currentBalance}'
                i.update()
                c.update()
                # print(installedAmount)

            if installedAmount == approvedDeposit:
                b.text="Deposit"
                b.bgcolor=ft.colors.GREEN_300
                b.on_click=fifthPage
                b.disabled=False
                client.messages.create(
                    body = f"Rs.{installedAmount} has been successfully deposited.",
                    from_ = '+17066403375', #phone number from twilio
                    to =  bank_num
                )
                b.update()
            else:
                b.text="Deposit"
                b.bgcolor=ft.colors.AMBER
                b.color=ft.colors.BLACK
                b.on_click=fifthPage
                b.disabled=False
                m.value=f"Waring: Rs.{approvedDeposit-installedAmount} lesser than actual approved amount."
                client.messages.create(
                    body = f"Rs.{approvedDeposit-installedAmount} lesser amount has been deposited than actual approved amount.",
                    from_ = '+17066403375', #phone number from twilio
                    to =  bank_num
                )
                b.update()
                m.update()

            
        b = ft.ElevatedButton(
            bgcolor=ft.colors.BLUE_300,
            text="Count",
            color=ft.colors.WHITE,
            on_click=counter,                            
        )

        page.add(
            ft.Container(
                content=ft.Column(            
                    [
                        ft.Container(
                            padding=ft.padding.only(bottom=50),
                            content=ft.Text('Deposit',size=50),
                        ),
                        c,
                        d,
                        i,
                        ft.Container(
                            padding=ft.padding.only(top=25,bottom=15),
                            content=b

                        ),
                        m
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                ),
                width=800,
                expand=True,
            )
        )


    def thirdPage(e):
        global face_names        
        page.clean()
        pr = ft.ProgressRing(width=16, height=16, stroke_width = 2)
        page.add(pr)
        page.clean()

        def windowClose(e):
            page.window_close()
        
        if face_names != "":
            r = requests.post("http://192.168.19.224:8080/atm/users/getUser",json={"id": face_names})
            if r != 'none':
                fromTime = datetime.datetime.strptime(r.json()['accessFrom'], '%H:%M:%S').time()
                toTime = datetime.datetime.strptime(r.json()['accessTo'], '%H:%M:%S').time()

                def time_in_range(start, end, x):
                    if start <= end:
                        return start <= x <= end
                    else:
                        return start <= x or x<=end
                
                if time_in_range(fromTime, toTime, datetime.datetime.now().time()):

                    username = r.json()['username']
                    otp = OPTGenerator().generate()
                    client.messages.create(
                        body = f'ATM NO:{atmID} || OTP: {otp}',
                        from_ = '+17066403375', #phone number from twilio
                        to =  face_names
                    )
                    print(otp)
                    
                    def validate(e):
                        print(e.control.value)
                        if e.control.value == str(otp):
                            b.disabled = False
                            b.bgcolor=ft.colors.BLUE_300
                            b.color=ft.colors.WHITE
                            b.update()
                        else :
                            b.disabled=True
                            b.bgcolor=ft.colors.BLACK26
                            b.color=ft.colors.WHITE38
                            b.update()

                    b = ft.ElevatedButton(
                        bgcolor=ft.colors.BLACK26,
                        text="Enter",
                        color=ft.colors.WHITE38,
                        on_click=fourthPage,
                        disabled=True,                                        
                    )
                    page.add(
                        ft.Container(
                            content=ft.Column(            
                                [
                                    ft.Container(
                                        padding=ft.padding.only(bottom=50),
                                        content=ft.Text(f'Hello {username}',size=50),
                                    ),
                                    ft.TextField(
                                        width=150,
                                        border_color=ft.colors.BLUE_300,
                                        border_width=2,
                                        border_radius=10,
                                        max_length=4,
                                        on_change=validate,
                                        text_size=25,
                                        text_align=ft.TextAlign.CENTER,                            
                                    ),
                                    b
                                ],
                                alignment=ft.MainAxisAlignment.CENTER,
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER
                            ),
                            width=800,
                            expand=True,
                        )
                    )
                    page.update()
                else:
                    client.messages.create(
                        body = f'UserID: {face_names} has logged in the ATM: {atmID} at unauthorized time.',
                        from_ = '+17066403375', #phone number from twilio
                        to =  bank_num
                    )
                    page.add(
                        
                        ft.Container(
                            content=ft.Column(            
                                [
                                    ft.Container(
                                        padding=ft.padding.only(bottom=25),
                                        content=ft.Text('TimeOut',size=50),
                                    ),
                                    ft.Container(
                                        padding=ft.padding.only(bottom=0),
                                        content=ft.Text('Access time expired. Please exit.'),
                                    ),
                                    ft.Container(
                                        padding=ft.padding.only(top=25),
                                        content=ft.ElevatedButton(
                                            bgcolor=ft.colors.RED_700,
                                            text="Exit",
                                            color=ft.colors.WHITE,
                                            on_click=windowClose,                            
                                        )

                                    ),                        
                                ],
                                alignment=ft.MainAxisAlignment.CENTER,
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER
                            ),
                            width=800,
                            expand=True,
                        )
                    )
                    page.update()
            else:                
                page.add(
                    ft.Container(
                        content=ft.Column(            
                            [
                                ft.Container(
                                    padding=ft.padding.only(bottom=25),
                                    content=ft.Text('Unknown User',size=50),
                                ),
                                ft.Container(
                                    padding=ft.padding.only(bottom=0),
                                    content=ft.Text('User not registered. Please exit.'),
                                ),
                                ft.Container(
                                    padding=ft.padding.only(top=25),
                                    content=ft.ElevatedButton(
                                        bgcolor=ft.colors.RED_700,
                                        text="Exit",
                                        color=ft.colors.WHITE,
                                        on_click=windowClose,                            
                                    )

                                ),                        
                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER
                        ),
                        width=800,
                        expand=True,
                    )
                )
                page.update()
        else:
            client.messages.create(
                body = f'Unknown user has logged in the ATM: {atmID}',
                from_ = '+17066403375', #phone number from twilio
                to =  bank_num
            )
            page.add(
                ft.Container(
                    content=ft.Column(            
                        [
                            ft.Container(
                                padding=ft.padding.only(bottom=25),
                                content=ft.Text('Unknown User',size=50),
                            ),
                            ft.Container(
                                padding=ft.padding.only(bottom=0),
                                content=ft.Text('Unauthorized login. Please exit.'),
                            ),
                            ft.Container(
                                padding=ft.padding.only(top=25),
                                content=ft.ElevatedButton(
                                    bgcolor=ft.colors.RED_700,
                                    text="Exit",
                                    color=ft.colors.WHITE,
                                    on_click=windowClose,                            
                                )

                            ),                        
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER
                    ),
                    width=800,
                    expand=True,
                )
            )
            page.update()

    def secondPage(e):
        cmd = 'processing...'
        result=None
        page.clean(),
        pr = ft.ProgressRing(width=16, height=16, stroke_width = 2)
        page.add(pr)
        page.update()

        cap = cv2.VideoCapture(0)
        ctrl = ft.Image(visible=False,fit=ft.ImageFit.FILL)

        page.clean()

        def up(data):
            ctrl.src_base64 = data
            ctrl.visible=True
            ctrl.update()

        

        c1 = ft.Container(
            width=300,
            height=300,
            border_radius=300,
            opacity=1.0,
            border=ft.border.all(20.0,color=ft.colors.BLUE_300)
        )
        c2 = ft.Container(
            width=300,
            height=300,
            border_radius=300,
            opacity=0.3,
            border=ft.border.all(20.0,color=ft.colors.BLUE_300)
        )
        c3 = ft.Container(
            width=300,
            height=300,
            border_radius=300,
            opacity=1,
            border=ft.border.all(20.0,color=ft.colors.RED_700)
        )
        c4 = ft.Container(
            width=300,
            height=300,
            border_radius=300,
            opacity=1,
            border=ft.border.all(20.0,color=ft.colors.GREEN_300)
        )
        c = ft.AnimatedSwitcher(
            c1,
            transition=ft.AnimatedSwitcherTransition.FADE,
            duration=1000,
            reverse_duration=1000,
            switch_in_curve=ft.AnimationCurve.EASE_IN,
            switch_out_curve=ft.AnimationCurve.EASE_OUT,
        )
        t1 = ft.Container(
            content= ft.Text(value=cmd,size=15,color=ft.colors.WHITE),
            opacity=1.0,
            padding=ft.padding.only(top=10)
        )
        t2 = ft.Container(
            content= ft.Text(value=cmd,size=15,color=ft.colors.WHITE),
            opacity=0.3,
            padding=ft.padding.only(top=10)
        )
        t3 = ft.Container(
            content= ft.Text(value="Unauthorized User",size=30,color=ft.colors.RED_700),
            opacity=1.0,
            padding=ft.padding.only(top=10)
        )
        t4 = ft.Container(
            content= ft.Text(value="Approved",size=30,color=ft.colors.GREEN_300),
            opacity=1.0,
            padding=ft.padding.only(top=10)
        )
        t5 = ft.Container(
            content= ft.Text(value="Timeout",size=30,color=ft.colors.WHITE),
            opacity=1.0,
            padding=ft.padding.only(top=10)
        )
        t = ft.AnimatedSwitcher(
            t1,
            transition=ft.AnimatedSwitcherTransition.FADE,
            duration=1000,
            reverse_duration=1000,
            switch_in_curve=ft.AnimationCurve.EASE_IN,
            switch_out_curve=ft.AnimationCurve.EASE_OUT,
        )
        page.add(
            ft.Container(
                content=ft.Column(            
                    [
                        ft.Container(
                            padding=ft.padding.only(bottom=20),
                            content=ft.Text('Face Recognition',size=50),
                        ),
                        ft.Stack(
                            [
                                c,
                                ft.Column(
                                    [
                                        ft.Container(
                                            width=280,
                                            height=280,
                                            border_radius=300,
                                            bgcolor=ft.colors.TRANSPARENT,
                                            content=ctrl,
                                            clip_behavior=ft.ClipBehavior.ANTI_ALIAS
                                        ),
                                    ],
                                    left=10,
                                    top=10,
                                    right=10  ,
                                    bottom=10                                  
                                    # alignment=ft.MainAxisAlignment.CENTER,
                                    # horizontal_alignment=ft.CrossAxisAlignment.CENTER
                                ),                                                                
                            ],                                                        
                        ),
                        t
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER
                ),
                width=800,
                expand=True,
            )
        )   

        def anim():
            global face_names
            global streaming
            count=0
            while count < 10:
                time.sleep(1.1)
                c.content = c2 if c.content == c1 else c1
                t.content = t2 if t.content == t1 else t1
                c.update()
                t.update()
                count += 1
                print(count) 
            if face_names == "":
                result = 0
            else:
                result = 1
            if result == 0:
                c.content = c3            
                t.content = t3
                c.update()
                t.update()
            elif result == 1:
                c.content = c4
                t.content = t4
                c.update()
                t.update()
            elif result == 2:
                t.content = t5
                t.update()
            
            streaming = False            
            time.sleep(2)                        
            thirdPage(e)    

        page.update()

        # anim()
        def stream():
            global streaming
            global face_names
            face_encodings = []
            face_locations = []
            process_current_frame = True
            cap = cv2.VideoCapture(0)

            while streaming:
                ret, frame = cap.read()
                retval, buffer = cv2.imencode('.jpg', frame)
                up(base64.b64encode(buffer).decode("utf-8"))

                if process_current_frame:
                    small_frame = cv2.resize(frame, (0,0), fx=0.25, fy=0.25)
                    rgb_small_frame = small_frame[:, :, ::-1]

                    face_locations = face_recognition.face_locations(rgb_small_frame)
                    face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
                    
                    for face_encoding in face_encodings:
                        matches = face_recognition.compare_faces(FaceEncoding.known_face_encoding, face_encoding)
                        name = 'Unknown'

                        face_distances = face_recognition.face_distance(FaceEncoding.known_face_encoding, face_encoding)
                        best_match_index = np.argmin(face_distances)


                        if matches[best_match_index]:
                            name = FaceEncoding.known_face_names[best_match_index]
                            if name != face_names:
                                face_names = name
                                print('01')
                                                
                # process_current_frame = not process_current_frame

                key= cv2.waitKey(1)
                if key == 27:
                    cap.release()
                    break
            
            cap.release()
            cv2.destroyAllWindows() 

        threading.Thread(target=anim).start()
        threading.Thread(target=stream).start()

    page.add(
        ft.Container(
            content=ft.Column(            
                [
                    ft.Text('ATM Application',size=72),
                    ft.Container(
                        padding=ft.padding.only(top=25),
                        content=ft.ElevatedButton(
                            bgcolor=ft.colors.BLUE_300,
                            text="Process",
                            color=ft.colors.WHITE,
                            on_click=secondPage,                            
                        )

                    ),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER
            ),
            width=800,
            expand=True,
        )
    )

FaceEncoding()
ft.app(target=main)

